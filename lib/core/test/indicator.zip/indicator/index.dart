import 'dart:math';
import 'package:flutter/material.dart';

part 'painter/base.dart';
part 'painter/warm.dart';
part 'painter/drop.dart';
part 'painter/none.dart';
part 'painter/color.dart';
part 'painter/slide.dart';
part 'painter/scale.dart';

enum PageIndicatorLayout { NONE, SLIDE, WARM, COLOR, SCALE, DROP, LINE }

/*return Container(
      height: 155,
      margin: EdgeInsets.fromLTRB(0, 18, 0, 0),
      child: Swiper.children(
        index: 0,
        loop: false,
        viewportFraction: .8,
        children: [walletView(), couponView(), toolView()],
        pagination: SwiperCustomPagination(
          builder: (BuildContext context, SwiperPluginConfig config) {
            return Container(
              alignment: Alignment.bottomCenter,
              child: PageIndicator(
                space: 2,
                size: 15,
                scale: .4,
                lineSize: 6,
                count: config.itemCount,
                controller: config.pageController,
                activeColor: AppColor.c_00B46E,
                color: AppColor.c_00B46E.withOpacity(.6),
              ),
            );
          },
        ),
      ),
    );*/
class PageIndicator extends StatefulWidget {
  final int count, index; // 数量
  final double size, space, activeSize; // 尺寸，间隔
  final Color color, activeColor; // 颜色
  final PageIndicatorLayout layout;
  final PageController controller;

  final bool dot; // 是否是点状

  /// Layout==PageIndicatorLayout.scale | Layout==PageIndicatorLayout.drop
  final double scale, dropSize;

  /// dot = false
  final double lineSize;
  final bool round;

  PageIndicator({
    Key key,
    this.count,
    this.index = 0,
    this.dot = false,
    this.size = 10,
    this.space = 6,
    this.controller,
    this.scale = .75,
    this.lineSize = 5,
    this.dropSize = 10,
    this.activeSize = 20,
    this.color = Colors.white30,
    this.layout = PageIndicatorLayout.SCALE,
    this.activeColor = Colors.white,
    this.round = true,
  })  : assert(count != null),
        assert(controller != null),
        super(key: key);

  @override
  State<StatefulWidget> createState() => _PageIndicatorState();
}

class _PageIndicatorState extends State<PageIndicator> {
  int index = 0;
  Paint _paint = Paint();

  @override
  void initState() {
    super.initState();
    index = widget.index;
    widget.controller.addListener(_onController);
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: (widget.layout == PageIndicatorLayout.SLIDE ||
              widget.layout == PageIndicatorLayout.WARM)
          ? ClipRect(child: view())
          : view(),
    );
  }

  BasePainter _createPainer() {
    switch (widget.layout) {
      case PageIndicatorLayout.NONE:
        return NonePainter(widget, widget.controller.page ?? 0.0, index, _paint,
            widget.dot, widget.lineSize, widget.round);
      case PageIndicatorLayout.SLIDE:
        return SlidePainter(widget, widget.controller.page ?? 0.0, index,
            _paint, widget.dot, widget.lineSize, widget.round);
      case PageIndicatorLayout.WARM:
        return WarmPainter(widget, widget.controller.page ?? 0.0, index, _paint,
            widget.dot, widget.lineSize, widget.round);
      case PageIndicatorLayout.COLOR:
        return ColorPainter(widget, widget.controller.page ?? 0.0, index,
            _paint, widget.dot, widget.lineSize, widget.round);
      case PageIndicatorLayout.SCALE:
        return ScalePainter(widget, widget.controller.page ?? 0.0, index,
            _paint, widget.dot, widget.lineSize, widget.round);
      case PageIndicatorLayout.DROP:
        return DropPainter(widget, widget.controller.page ?? 0.0, index, _paint,
            widget.dot, widget.lineSize, widget.round);
      default:
        throw Exception("Not a valid layout");
    }
  }

  Widget view() => SizedBox(
        width: widget.count > 0
            ? widget.count * widget.size + (widget.count - 1) * widget.space
            : 0,
        height: widget.size,
        child: CustomPaint(painter: _createPainer()),
      );

  void _onController() {
    double page = widget.controller.page ?? 0.0;
    index = page.floor();

    setState(() {});
  }

  @override
  void didUpdateWidget(PageIndicator oldWidget) {
    if (widget.controller != oldWidget.controller) {
      oldWidget.controller.removeListener(_onController);
      widget.controller.addListener(_onController);
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onController);
    super.dispose();
  }
}

class TabIndicator extends Decoration {
  final double width;
  final BorderSide borderSide;
  final EdgeInsetsGeometry insets;

  const TabIndicator({
    this.width = 40,
    this.insets = EdgeInsets.zero,
    this.borderSide = const BorderSide(width: 2, color: Colors.white),
  })  : assert(borderSide != null),
        assert(insets != null);

  @override
  Decoration lerpFrom(Decoration a, double t) {
    return a is TabIndicator
        ? TabIndicator(
            borderSide: BorderSide.lerp(a.borderSide, borderSide, t),
            insets: EdgeInsetsGeometry.lerp(a.insets, insets, t),
          )
        : super.lerpFrom(a, t);
  }

  @override
  Decoration lerpTo(Decoration b, double t) {
    return b is TabIndicator
        ? TabIndicator(
            borderSide: BorderSide.lerp(borderSide, b.borderSide, t),
            insets: EdgeInsetsGeometry.lerp(insets, b.insets, t),
          )
        : super.lerpTo(b, t);
  }

  @override
  _Painter createBoxPainter([VoidCallback onChanged]) =>
      _Painter(this, onChanged);
}

class _Painter extends BoxPainter {
  _Painter(this.decoration, VoidCallback onChanged)
      : assert(decoration != null),
        super(onChanged);

  final TabIndicator decoration;

  BorderSide get borderSide => decoration.borderSide;
  EdgeInsetsGeometry get insets => decoration.insets;

  Rect indicatorRectHandler(Rect rect, TextDirection textDirection) {
    assert(rect != null);
    assert(textDirection != null);
    final Rect indicator = insets.resolve(textDirection).deflateRect(rect);

    // 取中间坐标
    double center = (indicator.left + indicator.right) / 2;
    return Rect.fromLTWH(
        center - decoration.width / 2,
        indicator.bottom - borderSide.width,
        decoration.width,
        borderSide.width);
  }

  @override
  void paint(Canvas canvas, Offset offset, ImageConfiguration configuration) {
    assert(configuration != null);
    assert(configuration.size != null);
    final Rect rect = offset & configuration.size;
    final TextDirection textDirection = configuration.textDirection;
    final Rect indicator = indicatorRectHandler(rect, textDirection)
        .deflate(borderSide.width / 2.0);
    final Paint paint = borderSide.toPaint()..strokeCap = StrokeCap.round;
    canvas.drawLine(indicator.bottomLeft, indicator.bottomRight, paint);
  }
}
