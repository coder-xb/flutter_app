part of '../index.dart';

abstract class BasePainter extends CustomPainter {
  double page;
  final int index;
  final bool dot, round;
  final lineSize;
  final Paint mpaint;
  final PageIndicator widget;

  BasePainter(this.widget, this.page, this.index, this.mpaint, this.dot,
      [this.lineSize = 5, this.round = true]);

  double lerp(double begin, double end, double progress) =>
      begin + (end - begin) * progress;

  void draw(Canvas canvas, double space, double size, double radius);

  bool _shouldSkip(int index) => false;

  @override
  void paint(Canvas canvas, Size size) {
    mpaint.color = widget.color;
    double space = widget.space, msize = widget.size, radius = msize / 2;

    for (int i = 0, c = widget.count; i < c; ++i) {
      if (_shouldSkip(i)) continue;
      if (dot) {
        canvas.drawCircle(
            Offset(i * (msize + space) + radius, radius), radius, mpaint);
      } else {
        double x1 = i * (msize + space) + radius - msize / 2,
            x2 = i * (msize + space) + radius + msize / 2;

        round
            ? canvas.drawLine(Offset(x1 + lineSize / 2, radius),
                Offset(x2 - lineSize / 2, radius), mpaint)
            : canvas.drawLine(Offset(x1, radius), Offset(x2, radius), mpaint);
      }
    }

    if (page < index || page > widget.count - 1) page = 0.0;
    mpaint.color = widget.activeColor;
    draw(canvas, space, msize, radius);
  }

  @override
  bool shouldRepaint(BasePainter oldDelegate) => oldDelegate.page != page;
}
