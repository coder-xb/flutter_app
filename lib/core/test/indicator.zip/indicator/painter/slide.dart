part of '../index.dart';

class SlidePainter extends BasePainter {
  SlidePainter(
      PageIndicator widget, double page, int index, Paint paint, bool dot,
      [double lineSize = 5, bool round = true])
      : super(widget, page, index, paint, dot, lineSize, round);

  @override
  void draw(Canvas canvas, double space, double size, double radius) {
    double offset = radius + (page * (size + space));

    if (dot) {
      canvas.drawCircle(Offset(offset, radius), radius, mpaint);
    } else {
      mpaint.strokeWidth = lineSize;
      mpaint.strokeCap = round ? StrokeCap.round : StrokeCap.butt;
      double line = widget.size / 2;
      if (round) {
        double width = lineSize / 2;
        canvas.drawLine(Offset(offset - line + width, radius),
            Offset(offset + line - width, radius), mpaint);
      } else
        canvas.drawLine(Offset(offset - line, radius),
            Offset(offset + line, radius), mpaint);
    }
  }
}
