part of '../index.dart';

class DropPainter extends BasePainter {
  DropPainter(
      PageIndicator widget, double page, int index, Paint paint, bool dot,
      [double lineSize = 5, bool round = true])
      : super(widget, page, index, paint, dot, lineSize, round);

  @override
  void draw(Canvas canvas, double space, double size, double radius) {
    double progress = max(0, min(page - index, 1)),
        dropSize = widget.dropSize,
        rate = (0.5 - progress).abs() * 2,
        scale = widget.scale,
        offset1 = radius + ((page) * (size + space));
    if (dot) {
      canvas.drawCircle(Offset(offset1, radius - dropSize * (1 - rate)),
          radius * (scale + rate * (1.0 - scale)), mpaint);
    } else {
      mpaint.strokeWidth = lineSize;
      mpaint.strokeCap = round ? StrokeCap.round : StrokeCap.butt;
      double line = widget.size / 2;
      if (round) {
        double width = lineSize / 2;
        canvas.drawLine(
            Offset(offset1 - line + width, radius - dropSize * (1 - rate)),
            Offset(offset1 + line - width, radius - dropSize * (1 - rate)),
            mpaint);
      } else
        canvas.drawLine(Offset(offset1 - line, radius - dropSize * (1 - rate)),
            Offset(offset1 + line, radius - dropSize * (1 - rate)), mpaint);
    }
  }
}
