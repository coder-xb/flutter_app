part of '../index.dart';

class ColorPainter extends BasePainter {
  ColorPainter(
      PageIndicator widget, double page, int index, Paint paint, bool dot,
      [double lineSize = 5, bool round = true])
      : super(widget, page, index, paint, dot, lineSize, round);

  // 连续的两个点，含有最后一个和第一个
  @override
  bool _shouldSkip(int i) {
    if (index == widget.count - 1) return i == 0 || i == index;

    return (i == index || i == index + 1);
  }

  @override
  void draw(Canvas canvas, double space, double size, double radius) {
    double progress = max(0, min(page - index, 1)),
        offset1 = radius + (index * (size + space)),
        offset2 = index == widget.count - 1
            ? radius
            : radius + ((index + 1) * (size + space));

    mpaint.color = Color.lerp(widget.activeColor, widget.color, progress);

    if (dot) {
      canvas.drawCircle(Offset(offset1, radius), radius, mpaint);
      mpaint.color = Color.lerp(widget.color, widget.activeColor, progress);
      canvas.drawCircle(Offset(offset2, radius), radius, mpaint);
    } else {
      mpaint.strokeWidth = lineSize;
      mpaint.strokeCap = round ? StrokeCap.round : StrokeCap.butt;

      double line = widget.size / 2;
      if (round) {
        double width = lineSize / 2;
        canvas.drawLine(Offset(offset1 - line + width, radius),
            Offset(offset1 + line - width, radius), mpaint);
      } else
        canvas.drawLine(Offset(offset1 - line, radius),
            Offset(offset1 + line, radius), mpaint);

      mpaint.color = Color.lerp(widget.color, widget.activeColor, progress);

      if (round) {
        double width = lineSize / 2;
        canvas.drawLine(Offset(offset2 - line + width, radius),
            Offset(offset2 + line - width, radius), mpaint);
      } else
        canvas.drawLine(Offset(offset2 - line, radius),
            Offset(offset2 + line, radius), mpaint);
    }
  }
}
