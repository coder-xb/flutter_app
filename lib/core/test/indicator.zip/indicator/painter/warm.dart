part of '../index.dart';

class WarmPainter extends BasePainter {
  WarmPainter(
      PageIndicator widget, double page, int index, Paint paint, bool dot,
      [double lineSize = 5, bool round = true])
      : super(widget, page, index, paint, dot, lineSize, round);

  @override
  void draw(Canvas canvas, double space, double size, double radius) {
    double progress = max(0, min(page - index, 1));

    if (dot) {
      double distance = size + space, start = index * (size + space);
      if (progress > 0.5) {
        double right = start + size + distance,
            left = index * distance + distance * (progress - 0.5) * 2;
        canvas.drawRRect(
            RRect.fromLTRBR(left, 0.0, right, size, Radius.circular(radius)),
            mpaint);
      } else {
        double right = start + size + distance * progress * 2;
        canvas.drawRRect(
            RRect.fromLTRBR(start, 0.0, right, size, Radius.circular(radius)),
            mpaint);
      }
    } else {
      mpaint.strokeWidth = lineSize;
      mpaint.strokeCap = round ? StrokeCap.round : StrokeCap.butt;

      double distance = size + space, start = index * (size + space);

      if (progress > 0.5) {
        double right = start + size + distance,
            left = index * distance + distance * (progress - 0.5) * 2;
        if (round) {
          canvas.drawRRect(
              RRect.fromLTRBR(left, (size - lineSize) / 2, right,
                  (size + lineSize) / 2, Radius.circular(radius)),
              mpaint);
        } else
          canvas.drawRect(
              Rect.fromLTRB(
                  left, (size - lineSize) / 2, right, (size + lineSize) / 2),
              mpaint);
      } else {
        double right = start + size + distance * progress * 2;
        if (round) {
          canvas.drawRRect(
              RRect.fromLTRBR(start, (size - lineSize) / 2, right,
                  (size + lineSize) / 2, Radius.circular(radius)),
              mpaint);
        } else
          canvas.drawRect(
              Rect.fromLTRB(
                  start, (size - lineSize) / 2, right, (size + lineSize) / 2),
              mpaint);
      }
    }
  }
}
