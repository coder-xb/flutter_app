part of '../index.dart';

class NonePainter extends BasePainter {
  NonePainter(
      PageIndicator widget, double page, int index, Paint paint, bool dot,
      [double lineSize = 5, bool round = true])
      : super(widget, page, index, paint, dot, lineSize, round);

  @override
  void draw(Canvas canvas, double space, double size, double radius) {
    double progress = max(0, min(page - index, 1)),
        offset1 = radius + (index * (size + space)),
        offset2 = index == widget.count - 1
            ? radius
            : radius + ((index + 1) * (size + space));

    if (dot) {
      progress > 0.5
          ? canvas.drawCircle(Offset(offset2, radius), radius, mpaint)
          : canvas.drawCircle(Offset(offset1, radius), radius, mpaint);
    } else {
      mpaint.strokeWidth = lineSize;
      mpaint.strokeCap = round ? StrokeCap.round : StrokeCap.butt;

      double line = widget.size / 2;
      if (round) {
        double width = lineSize / 2;
        progress > 0.5
            ? canvas.drawLine(Offset(offset2 - line + width, radius),
                Offset(offset2 + line - width, radius), mpaint)
            : canvas.drawLine(Offset(offset1 - line + width, radius),
                Offset(offset1 + line - width, radius), mpaint);
      } else
        progress > 0.5
            ? canvas.drawLine(Offset(offset2 - line, radius),
                Offset(offset2 + line, radius), mpaint)
            : canvas.drawLine(Offset(offset1 - line, radius),
                Offset(offset1 + line, radius), mpaint);
    }
  }
}
