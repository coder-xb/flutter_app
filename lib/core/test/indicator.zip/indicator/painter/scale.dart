part of '../index.dart';

class ScalePainter extends BasePainter {
  ScalePainter(
      PageIndicator widget, double page, int index, Paint paint, bool dot,
      [double lineSize = 5, bool round = true])
      : super(widget, page, index, paint, dot, lineSize, round);

  // 连续的两个点，含有最后一个和第一个
  @override
  bool _shouldSkip(int i) {
    if (index == widget.count - 1) return i == 0 || i == index;
    return (i == index || i == index + 1);
  }

  @override
  void paint(Canvas canvas, Size size) {
    mpaint.color = widget.color;
    double space = widget.space, msize = widget.size, radius = msize / 2;

    for (int i = 0, c = widget.count; i < c; ++i) {
      if (_shouldSkip(i)) continue;
      if (dot) {
        canvas.drawCircle(Offset(i * (msize + space) + radius, radius),
            radius * widget.scale, mpaint);
      } else {
        double x1 = i * (msize + space) + radius - (msize * widget.scale) / 2,
            x2 = i * (msize + space) + radius + (msize * widget.scale) / 2;
        round
            ? canvas.drawLine(Offset(x1 + lineSize / 2, radius),
                Offset(x2 - lineSize / 2, radius), mpaint)
            : canvas.drawLine(Offset(x1, radius), Offset(x2, radius), mpaint);
      }
    }

    if (page < index || page > widget.count - 1) page = 0.0;
    mpaint.color = widget.activeColor;
    draw(canvas, space, msize, radius);
  }

  @override
  void draw(Canvas canvas, double space, double size, double radius) {
    double progress = max(0, min(page - index, 1)),
        offset1 = radius + (index * (size + space)),
        offset2 = index == widget.count - 1
            ? radius
            : radius + ((index + 1) * (size + space));

    mpaint.color = Color.lerp(widget.activeColor, widget.color, progress);
    if (dot) {
      canvas.drawCircle(Offset(offset1, radius),
          lerp(radius, radius * widget.scale, progress), mpaint);
      mpaint.color = Color.lerp(widget.color, widget.activeColor, progress);
      canvas.drawCircle(Offset(offset2, radius),
          lerp(radius * widget.scale, radius, progress), mpaint);
    } else {
      mpaint.strokeWidth = lineSize;
      mpaint.strokeCap = round ? StrokeCap.round : StrokeCap.butt;

      if (round) {
        double width = lineSize / 2;
        canvas.drawLine(
            Offset(
                lerp(offset1 - size / 2 + width,
                    offset1 - size * widget.scale / 2 + width, progress),
                radius),
            Offset(
                lerp(offset1 + size / 2 - width,
                    offset1 + size * widget.scale / 2 - width, progress),
                radius),
            mpaint);
      } else
        canvas.drawLine(
            Offset(
                lerp(offset1 - size / 2, offset1 - size * widget.scale / 2,
                    progress),
                radius),
            Offset(
                lerp(offset1 + size / 2, offset1 + size * widget.scale / 2,
                    progress),
                radius),
            mpaint);

      mpaint.color = Color.lerp(widget.color, widget.activeColor, progress);

      if (round) {
        double width = lineSize / 2;

        canvas.drawLine(
            Offset(
                lerp(offset2 - size * widget.scale / 2 + width,
                    offset2 - size / 2 + width, progress),
                radius),
            Offset(
                lerp(offset2 + size * widget.scale / 2 - width,
                    offset2 + size / 2 - width, progress),
                radius),
            mpaint);
      } else {
        canvas.drawLine(
            Offset(
                lerp(offset2 - size * widget.scale / 2, offset2 - size / 2,
                    progress),
                radius),
            Offset(
                lerp(offset2 + size * widget.scale / 2, offset2 + size / 2,
                    progress),
                radius),
            mpaint);
      }
    }
  }
}
